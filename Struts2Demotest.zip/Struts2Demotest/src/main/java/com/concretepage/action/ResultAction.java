package com.concretepage.action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.ResultPath;

import com.concretepage.persistence.Books;
import com.concretepage.pojo.AuthorDTO;
import com.concretepage.service.AuthorService;
import com.opensymphony.xwork2.ActionSupport;
@Namespace("/user")
@ResultPath(value="/")
@Action(value="result", results={@Result(name="success",location="result.jsp")})
public class ResultAction extends ActionSupport{
	private static final long serialVersionUID = 1L;
	private String name;
	
	AuthorDTO dto=new AuthorDTO();
	List<AuthorDTO> authorList=new ArrayList<AuthorDTO>();
	
	public List<AuthorDTO> getAuthorList() {
		return authorList;
	}
	public void setAuthorList(List<AuthorDTO> authorList) {
		this.authorList = authorList;
	}
	
	public String execute() {
		
		Books books=new Books();
		books.setName(name);
		
		/*Author author=new Author();
		author.setName(name);
		author.setEmail(email);*/
		
	   AuthorService userDao = new AuthorService();
	   authorList=userDao.getAuthorDetail(name);
	   //userDao.saveBookDetail(books);
	   return SUCCESS; 
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
/*	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}*/
/*	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	*/

}