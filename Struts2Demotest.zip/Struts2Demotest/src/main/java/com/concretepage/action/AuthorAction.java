package com.concretepage.action;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.ResultPath;

import com.opensymphony.xwork2.ActionSupport;


	@Namespace("/author")
	@Action("/author")
	@ResultPath(value="/")
	@Result(name="success",location="user.jsp")
	public class AuthorAction extends ActionSupport{

		private static final long serialVersionUID = 1L;

		public String execute() {
		    return SUCCESS;
		}
	}


