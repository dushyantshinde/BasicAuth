package com.concretepage.service;

import com.concretepage.dao.UserDao;
import com.concretepage.persistence.User;

public class UserService {

	public void  saveUserDetail(User user){
		UserDao userDao = new UserDao();
		userDao.saveUserDetail(user);
	}
}
