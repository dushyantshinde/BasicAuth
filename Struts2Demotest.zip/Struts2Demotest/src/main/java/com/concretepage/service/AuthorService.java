package com.concretepage.service;

import java.util.ArrayList;
import java.util.List;

import com.concretepage.dao.AuthorDao;
import com.concretepage.persistence.Author;
import com.concretepage.persistence.Books;
import com.concretepage.pojo.AuthorDTO;

public class AuthorService {
	public void  saveAuthorDetail(Author user){
		AuthorDao userDao = new AuthorDao();
		userDao.saveAuthorDetail(user);
	}
	
	public void  saveBookDetail(Books user){
		AuthorDao userDao = new AuthorDao();
		userDao.saveBookDetail(user);
	}
	
	public  List<AuthorDTO> getAuthorDetail(String name){
		  AuthorDao userDao = new AuthorDao();
		  List<Author> userList= userDao.getAuthorDetail(name);
		  List<AuthorDTO> dtoList=new ArrayList<AuthorDTO>();
		  AuthorDTO dto=null;
		  for(Author u:userList){
			  dto=new AuthorDTO();
			  dto.setName(u.getName());
			  dto.setEmail(u.getEmail());
			  String val = "";
			  	if(u.getBooks()!=null){
			  		for(Books book:u.getBooks()){
			  			val=val+book.getName()+" ";
			  		}
				 }
			    dto.setBookList(val);
			    dtoList.add(dto);
			 
		  }
		 
		  
		  return dtoList;
	  }
}
