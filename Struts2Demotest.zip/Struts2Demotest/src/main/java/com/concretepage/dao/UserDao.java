package com.concretepage.dao;

import org.hibernate.Session;

import com.concretepage.HibernateUtil;
import com.concretepage.persistence.User;

public class UserDao {
  public void saveUserDetail(User user){
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		session.save(user);
		session.getTransaction().commit();
		session.close();
		System.out.println("done");
  }
}
