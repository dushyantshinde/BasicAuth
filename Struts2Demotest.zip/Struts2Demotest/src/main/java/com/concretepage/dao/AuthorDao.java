package com.concretepage.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.concretepage.HibernateUtil;
import com.concretepage.persistence.Author;
import com.concretepage.persistence.Books;


public class AuthorDao {
	
	Author author=new Author();
	List<Author> authorList=new ArrayList<Author>();
	public void saveAuthorDetail(Author user){
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		session.save(user);
		session.getTransaction().commit();
		session.close();
		System.out.println("done");
  }
	
	public void saveBookDetail(Books user){
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		session.save(user);
		session.getTransaction().commit();
		session.close();
		System.out.println("done");
  }
	
	public List<Author> getAuthorDetail(String name){
		    Session session = HibernateUtil.getSession();
		    
//		    Criteria crit = session.createCriteria(Author.class);
//		     crit.add(Restrictions.eq("name", name));
		       // crit.add( Restrictions.like("name", name + "%"));
//		     elect cont " +
//		        "from Continent cont join fetch cont.countries " +
//		        "where cont.name = 'Europe'
		    String hql = "from Author where name like :name";
		    Query query = session.createQuery(hql);
		    query.setParameter("name","%"+name+"%");
		    authorList= query.list();
		    
		   
		   // System.out.println(authorList.get(0).toString());
			//session.close();
			return authorList;
		  
	 }

}
