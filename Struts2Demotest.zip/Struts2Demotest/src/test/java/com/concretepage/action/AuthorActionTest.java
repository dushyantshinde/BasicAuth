package com.concretepage.action;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.LinkedList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.concretepage.dao.AuthorDao;
import com.concretepage.persistence.Author;
import com.concretepage.pojo.AuthorDTO;
import com.concretepage.service.AuthorService;
import com.opensymphony.xwork2.interceptor.annotations.Before;

@RunWith(MockitoJUnitRunner.class)
public class AuthorActionTest {

	@Mock
    private AuthorService authorService;
	
	@Mock
    private AuthorDao authorDao;
	
	@Mock 
	private Author author;
	
	String name="D";

    @Before
    public void setupMock() {
       MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testMockCreation(){
    	assertNotNull(author);
        assertNotNull(authorService);
    }
   /* 
    @Test
    public void testDaoCalledOnlyOnce() {
    	
    	 List<AuthorDTO> all = new LinkedList<AuthorDTO>();
    	 
    	 all=authorService.getAuthorDetail(name);
    	 
    	 System.out.println(all);
    	 
    	 assertTrue("List is empty!", all.size() == 1);
    	 }
    */
  
}
